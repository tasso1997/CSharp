﻿using System;


namespace Assignment3
{
    class CheckingDays
    {
        static void Main()
        {
            //using numbers checking days of week 
            Console.WriteLine("===============Days of Week==============");

            Console.WriteLine("Enter the number(1,2,3,4,5,6,7):");
            int day = Convert.ToInt32(
         Console.ReadLine());
            switch (day)
            {
                case 1:
                    Console.WriteLine("1 :Sunday");
                    break;
                case 2:
                    Console.WriteLine("2 :Monday");
                    break;
                case 3:
                    Console.WriteLine("3 :Tueday");
                    break;
                case 4:
                    Console.WriteLine("4 :Wednesday");
                    break;
                case 5:
                    Console.WriteLine("5 :Thursday");
                    break;
                case 6:
                    Console.WriteLine("6 :Friday");
                    break;
                case 7:
                    Console.WriteLine("7 :Saturday");
                    break;
                default:
                    Console.WriteLine("INVALID INPUT");
                    break;
            }
            Console.ReadLine();
        }
    }
}
