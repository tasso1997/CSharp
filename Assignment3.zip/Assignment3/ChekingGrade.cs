﻿using System;


namespace Assignment3
{
    class CheckingGrade
    {
        static void Main()
        {
            //checking grade using percentage
            Console.WriteLine("===============Percentage==============");

            Console.WriteLine("Enter the percentage:");
            double per = Convert.ToDouble(
            Console.ReadLine());
            if (per >= 75)
            {
                Console.WriteLine("Grade:O");
            }
            else if (per >= 65 && per <= 74)
            {
                Console.WriteLine("Grade:A");
            }
            else if (per >= 45 && per <= 64)
            {
                Console.WriteLine("Grade:B");
            }
            else
            {
                Console.WriteLine("Grade:C");
            }
            Console.ReadLine();
        }
    }
}
