﻿using System;

namespace Assignment3
{
    class UsingTernaryOperator
    {

        static void Main()
        {

            //Checking Person is major or minor using ternary operator
            Console.WriteLine("==================Ternary Operator==============");
            Console.WriteLine("Enter the age:");
            int age = Convert.ToInt32(
            Console.ReadLine());
            string str = age > 18 ? "person is major" : "person is minor";
            Console.WriteLine(str);

            Console.ReadLine();
        }
    }
}
