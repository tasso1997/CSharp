﻿using System;


namespace Assignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            //1]check person is major and minor
            Console.WriteLine("===============Major and minor==============");

            Console.WriteLine("Enter the age:");
            int age = Convert.ToInt32(
            Console.ReadLine());
            if (age >= 18)
            {

                Console.WriteLine("...Major...");
            }
            else
            {

                Console.WriteLine("...Minor...");
            }

            Console.ReadLine();
        }
    }
}
