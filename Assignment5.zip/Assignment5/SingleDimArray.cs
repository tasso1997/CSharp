﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    class SingleDimArray
    {
        static void Main()
        {
            Console.WriteLine("===============Sum of single dimention array==============");
            int[] num1 = new int[5];
            Console.WriteLine("Enter Element");
            int sum = 0;
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("enter {0} element", i + 1);
                num1[i] = Convert.ToInt32(Console.ReadLine());
                sum = sum + num1[i];
            }
            Console.WriteLine("sum of array is {0}", sum);
            Console.ReadLine();
        }
    }
}