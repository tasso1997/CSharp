﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    class CharToAscii
    {
        static void Main()
        {
            //Printing ascii from a to i
            Console.WriteLine("Character to ASCII value");
            int charascii;
            for (char ch = 'a'; ch <= 'i'; ch++)
            {
                charascii = ch;
                Console.WriteLine("{0}={1}\t",ch, charascii);
                if (charascii % 3 == 0)
                    Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
