﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    class DiagonalSum
    {
        static void Main()
        {
            //sum of diagonal elements
            Console.WriteLine("===============Sum of diagonal elements==============");
            int[,] num2 = new int[3, 3];
            Console.WriteLine("enter element");
            for (int j = 0; j < 3; j++)
            {
                for (int k = 0; k < 3; k++)
                {
                    num2[j, k] = Convert.ToInt32(Console.ReadLine());
                }
            }
            int diagonal = 0;
            for (int j = 0; j < 3; j++)
            {
                for (int l = 0; l < 3; l++)
                {
                    if (j == l)
                    {
                        diagonal += num2[j, l];
                    }
                }
            }
            Console.WriteLine("Sum of diagonals are {0}", diagonal);
            Console.ReadLine();
        }
    }
}