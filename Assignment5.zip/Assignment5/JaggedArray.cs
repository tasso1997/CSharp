﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    class JaggedArray
    {
        static void Main()
        {
            int[][] num3 = new int[2][];
            num3[0] = new int[3] { 10, 20, 30 };
            num3[1] = new int[2] { 40, 50 };

            Console.WriteLine("Enter target element:");
            int target = Convert.ToInt32(Console.ReadLine());
            int flag = 0;

            for (int m = 0; m < 2; m++)
            {
                foreach (var t in num3[m])
                {
                    if (t == target)
                    {

                        Console.WriteLine("target found");
                        flag = 1;
                        break;
                    }
                }
            }
            Console.ReadLine();
        }
    }
}
