﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    class SumOfRows
    {
        static void Main(string[] args)
        {
            //printing sum of rows
            int[,] num4 =
            {
                {10,20,30 },{40,50,60},{70,80,90}
            };
            int[] rowsum = new int[3];
            int r1sum;
            for (int a = 0; a < 3; a++)
            {
                r1sum = 0;
                for (int b = 0; b < 3; b++)
                {
                    r1sum = r1sum + num4[a, b];
                }
                rowsum[a] = r1sum;
            }
            Console.WriteLine("Sum of :");

            for (int a = 0; a < 3; a++)
            {
                Console.WriteLine("rows {0} ={1}", a + 1, rowsum[a]);
            }
            Console.ReadLine();
        }
    }
}
