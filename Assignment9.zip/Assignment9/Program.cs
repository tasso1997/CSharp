﻿using System;
using GSTLibrary;

namespace GSTdemo1
{
    class Program
    {
        static void Main(string[] args)
        {
            double gstamt;
            Console.WriteLine("Enter amount:");
            double amount = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter percentage:");
            double per= Convert.ToDouble(Console.ReadLine());

            GSTDemo gs = new GSTDemo(amount, per);
          
            Console.WriteLine($"Total amount is :{ gs.Calculate(out gstamt)}");
            Console.WriteLine($"GST amount is :{ gstamt}");
            Console.ReadLine();
        }
    }
}
