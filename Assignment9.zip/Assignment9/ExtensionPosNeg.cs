﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdvancedConcept
{
   public static class ExtensionPosNeg
    {
        public static int IsPositive(this int i,int value)
        {
            if(i>0)
            {
                return i + value;
            }
            else
            {
                return -1;
            }

        }
    }
    class ExtenstionDmo
    {
        static void Main()
        {
            Console.WriteLine("==Check is number  positive or negative==");
           Console.WriteLine("Enter:");
            int i = Convert.ToInt32(Console.ReadLine());
            int result = i.IsPositive(5);
            Console.WriteLine($"After adding 5 :{ result}");
            Console.ReadLine();
        }
    }
}
