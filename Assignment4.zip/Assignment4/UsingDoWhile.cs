﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    class UsingDoWhile
    {
        static void Main()
        {
            //printing odd number using do-while loop
            Console.WriteLine("===============Do While Odd Numbers==============");
            int j = 1;
            do
            {
                if (j % 2 != 0)
                {
                    Console.WriteLine(j);
                }
                j++;

            } while (j <= 50);
            Console.ReadLine();
        }
    }
}
