﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    class UsingForEach
    {
        static void Main()
        {
            //printing even and odd number using foreach loop
            Console.WriteLine("===============For Each Odd Numbers==============");
            int[] num = new int[50];
            for (int k = 0; k < 50; k++)
            {
                num[k] = k + 1;
            }
            foreach (int temp in num)
            {
                if (temp % 2 != 0)
                {
                    Console.WriteLine(temp);
                }
            }

            Console.WriteLine("===============For Each Even Numbers==============");
            foreach (int temp in num)
            {
                if (temp % 2 == 0)
                {
                    Console.WriteLine(temp);
                }
            }
            Console.ReadLine();
        }
    }
}
