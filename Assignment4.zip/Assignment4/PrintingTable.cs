﻿using System;

namespace Assignment4
{
    class PrintingTable
    {
        static void Main()
        {
            //printing table of given number
            Console.WriteLine("===============Print Table==============");
            Console.WriteLine("Enter the number:");
            int no = Convert.ToInt32(Console.ReadLine());

            for (int z = 1; z <= 10; z++)
            {
                Console.WriteLine("{0} * {1} ={2}", no, z, no * z);
            }
            Console.ReadLine();
        }
    }
}
