﻿using System;


namespace Assignment4
{
    class Program
    {
        static void Main(string[] args)
        {
            //Reverse the number 1 to 50
            Console.WriteLine("===============Reverse the number==============");
            for (int i = 50; i >= 1; i--)
            {
                Console.WriteLine(i);
            }
            Console.ReadLine();

        }
    }
}
