﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class StructureAssignment
    {
        static void Main()
        {
            student s = new student(1,"taslim","female",16757434);
           Console.WriteLine( s.Dispaly());
            Console.ReadLine();
            }
        
    }
    struct student
    {
        int roll;
        string name;
        string gender;
        int mobno;

        public student(int roll,string name,string gender,int mobno)
        {
            this.roll = roll;
            this.name = name;
            this.gender = gender;
            this.mobno = mobno;
        }
        public string Dispaly()
        {
            return string.Format("Roll no={0}\nName={1}\nGender={2}\nMobile={3}\n", roll, name, gender, mobno);
        }
    }
}
