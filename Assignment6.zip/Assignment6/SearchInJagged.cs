﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class SearchInJagged
    {
        static void Main()
        {
            int[][] num = new int[2][];
            num[0] = new int[] { 10, 20, 30 };
            num[1] = new int[] { 40, 50 };
            Console.WriteLine("Enter element:");
            int target = Convert.ToInt32(Console.ReadLine());
            SearchInJagged sinj = new SearchInJagged();
           sinj.JaggedArray(target,num);
            Console.ReadLine();
        }

        public void JaggedArray(int x,int[][] num)
        {
            

            int flag = 0;
            for(int i=0;i<2;i++)
            {
                foreach(int temp in num[i])
                {
                    if (x == temp)
                    {
                        Console.WriteLine("Element found");
                        flag = 1;
                        break;
                    }
                }
                if(flag==1)
                {
                    break;
                }
                
               
            }
            if (flag == 0)
            {
                Console.WriteLine("Element not found...");
            }
        }
    }
}
