﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class SimpleInterest
    {
        static void Main()
        {
            Console.WriteLine("Enter principle amount:");
            int principle = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter rate:");
            int rate = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter time:");
            int time = Convert.ToInt32(Console.ReadLine());
            SimpleInterest si = new SimpleInterest();
            si.SimpleInt(principle, rate, time);
            Console.ReadLine();
        }

        public void SimpleInt(int p,int r,int t)
        {
            double SI = (p * r * t)/100;
            Console.WriteLine("Simple interest is :{0} ",SI);

        }
    }
}
