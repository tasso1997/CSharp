﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class factorialNumber
    {
        static void Main()
        {
            factorialNumber asmt= new factorialNumber();
            Console.WriteLine("Enter the number:");
            int num = Convert.ToInt32(Console.ReadLine());
           Console.WriteLine("Factorial is {0}:", asmt.factorial(num));
            Console.ReadLine();

        }

        public int factorial(int x)
        {
            int fact = 1;
           
            for(int i=2;i<=x;i++)
            {
                fact = fact * i;
            }
            return fact;

        }
        
    }
}
