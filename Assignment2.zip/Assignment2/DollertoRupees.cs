﻿using System;


namespace Assignment1
{
    class DollertoRupees
    {
        static void Main()
        {
            Console.WriteLine("Enter doller:");
            double doller= Convert.ToDouble(Console.ReadLine()); 
            double rupees =doller*76;
            Console.WriteLine("Rupees are {0}",rupees);
            
            Console.WriteLine("Enter rupees:");
            int rupees2 = Convert.ToInt32(Console.ReadLine()); 
            double doller2 = (double)rupees2 /76;
            Console.WriteLine("Dollers are {0}",doller2);
            Console.ReadLine();
        }
    }
}
