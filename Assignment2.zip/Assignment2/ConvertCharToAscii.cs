﻿using System;

namespace Assignment1
{
    class ConvertCharToAscii
    {
        static void Main()
        {
            Console.WriteLine("Enter character:");
            char c = Convert.ToChar(Console.ReadLine()); ;
            int d =(int)c;
            Console.WriteLine(d);
            Console.WriteLine("Enter ASCII value:");
            int d1 = Convert.ToInt32(Console.ReadLine()); ;
            char b =(char) d1;
            Console.WriteLine(b);
            Console.ReadLine();


        }
    }
}
