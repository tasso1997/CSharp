﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class StructureAssignment
    {
        static void Main()
        {
            student s = new student(1,"abc","female",16757);
           Console.WriteLine( s.Dispaly());
            Console.ReadLine();
            }
        
    }
    struct student
    {
        int roll;
        string name;
        string gender;
        int mobno;

        public student(int roll,string name,string gender,int mobno)
        {
            this.roll = roll;
            this.name = name;
            this.gender = gender;
            this.mobno = mobno;
        }
        public string Dispaly()
        {
            return string.Format("Roll no={0},Name={1},Gender={2},Mobile={3}", roll, name, gender, mobno);
        }
    }
}
