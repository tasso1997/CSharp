﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Assignment5
    {
        static void Main()
        {
            Console.WriteLine("===============Sum of single dimention array==============");
            int[] num1 = new int[5];
            Console.WriteLine("enter element");
            int sum = 0;
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("enter {0} element", i + 1);
                num1[i] = Convert.ToInt32(Console.ReadLine());
                sum = sum + num1[i];
            }
            Console.WriteLine("sum of array is {0}", sum);

            //sum of diagonal elements
            Console.WriteLine("===============Sum of diagonal elements==============");
            int[,] num2 = new int[3, 3];
            Console.WriteLine("enter element");
            for (int j = 0; j < 3; j++)
            {
                for (int k = 0; k < 3; k++)
                {
                    num2[j, k] = Convert.ToInt32(Console.ReadLine());
                }
            }
            int diagonal = 0;
            for (int j = 0; j < 3; j++)
            {
                for (int l = 0; l < 3; l++)
                {
                    if (j == l)
                    {
                        diagonal += num2[j, l];
                    }
                }
            }
            Console.WriteLine("Sum of diagonals are {0}",diagonal);


         
         

            //printing sum of rows
            int[,] num4 =
            {
                {10,20,30 },{40,50,60},{70,80,90}
            };
            int[] rowsum = new int[3];
            int rsum;
            for(int a=0;a<3;a++)
            {
                rsum = 0;
                for (int b = 0; b < 3; b++)
                {
                    rsum = rsum + num4[a, b];
                }
                rowsum[a] = rsum;
            }
            Console.WriteLine("Sum is :");

            for (int a = 0; a < 3; a++)
            {
                Console.WriteLine("rows {0} ={1}", a + 1, rowsum[a]);
            }

            //Printing ascii from a to i
            Console.WriteLine("Character to ASCII value");
            int charascii;
            for(char ch='a';ch<='i';ch++)
            {
                charascii = ch;
                Console.WriteLine("{0}\t", charascii);
                if (charascii % 3 == 0)
                    Console.WriteLine();
            }
            Console.ReadLine();

        }
    }
}
