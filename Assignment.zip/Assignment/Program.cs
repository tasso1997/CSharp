﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class AreaOfCircle
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter radius:");
            int r = Convert.ToInt32(Console.ReadLine());
            const double PI = 3.14;
            double area = r * r * PI;
            Console.WriteLine("Area of circle is {0}",area);
            Console.ReadLine();
        }
    }
}
