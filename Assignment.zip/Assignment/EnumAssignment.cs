﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class EnumOperation
    {
        static void Main()
        {
            foreach(var temp in Enum.GetNames(typeof(cities)))
            {
                Console.WriteLine($"Cities are :{ temp}");
            }
            foreach (int temp1 in Enum.GetValues(typeof(cities)))
            {
                Console.WriteLine($"Codes are :{ temp1}");
            }
            Console.ReadLine();
        }
    }
   
  
        enum cities
         {
        pune=11,mumbai=12,delhi=13,kolkata=14
         
    }
}
