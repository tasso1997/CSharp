﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class GSTOptional
    {
        static void Main()
        {
            Console.WriteLine("Enter per:");
            double per = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter amount:");
            double ant = Convert.ToDouble(Console.ReadLine());
            double gst;
            GSTOptional gp = new GSTOptional();
            gp.OutGST(out gst,ant, per);
            Console.ReadLine();
        }
        public void OutGST(out double Gstamount, double amount, double gst_per = 0.01)
        {
            Gstamount = ( gst_per/100) * amount;
            Console.WriteLine("GST amount is {0}:",Gstamount);
        }
    }
}
    
