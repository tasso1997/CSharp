﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class OutParamInterest
    {
        static void Main()
        {
            Console.WriteLine("Enter principle amount:");
            int principle = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter rate:");
            int rate = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter time:");
            int time = Convert.ToInt32(Console.ReadLine());

            double total;
            OutParamInterest opi = new OutParamInterest();
            opi.SimpleInt(principle, rate, time,out total);
            Console.ReadLine();
        }

        public void SimpleInt(int p, int r, int t,out double total)
        {
            double SI = (p * r * t) / 100;
            Console.WriteLine("Simple interest is {0} :", SI);
            total = p + SI;
            Console.WriteLine("total payable  is {0} :", total);

        }
    }
}
