﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Assignment3
    {
        static void Main()
        {
            //Reverse the number 1 to 50
            Console.WriteLine("===============Reverse the number==============");
            for (int i = 50; i >= 1; i--)
            {
                Console.WriteLine(i);
            }

            //printing odd number using do-while loop
            Console.WriteLine("===============Do While Odd Numbers==============");
            int j = 1;
            do
            {
                if (j % 2 != 0)
                {
                    Console.WriteLine(j);
                }
                j++;

            } while (j <= 50);

            //printing even and odd number using foreach loop
            Console.WriteLine("===============For Each Odd Numbers==============");
            int[] num = new int[50];
            for (int k = 0; k < 50; k++)
            {
                num[k] = k + 1;
            }
            foreach(int temp in num)
            {
                if(temp % 2!=0)
                {
                    Console.WriteLine(temp);
                }
            }


            Console.WriteLine("===============For Each Even Numbers==============");
            foreach (int temp in num)
            {
                if (temp % 2 == 0)
                {
                    Console.WriteLine(temp);
                }
            }

            //printing table of given number
            Console.WriteLine("===============Print Table==============");
            Console.WriteLine("Enter the number:");
            int no = Convert.ToInt32(Console.ReadLine());

            for (int z = 1; z <= 10; z++)
            {
                Console.WriteLine("{0} * {1} ={2}", no, z, no * z);
            }
            Console.ReadLine();
        }
        

    }
}
