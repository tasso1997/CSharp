﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    class Room
    {
        private int number, floor, capacity;
        private string type;
        private double price;
        private DateTime bookedTime;

        public int Number  //using properties

        {
            get
            {
                return number;
            }
            set
            {
                number = value;
            }
        }

        public int Floor

        {
            get
            {
                return floor;
            }
            set
            {
                floor = value;
            }
        }
        public int Capacity

        {
            get
            {
                return capacity;
            }
            set
            {
                capacity = value;
            }
        }

        public string Type

        {
            get
            {
                return type;
            }
            set
            {
                type = value;
            }
        }

        public double Price

        {
            get
            {
                return price;
            }
            set
            {
                price = value;
            }
        }

        public DateTime BookedTime

        {
            get
            {
                return bookedTime;
            }
            set
            {
                bookedTime = value;
            }
        }

        public Room() //default constructor
        {
            Console.WriteLine("Default constructor of room");
        }
        public Room(int number,int floor,string type,int capacity,DateTime bookedTime, double price) //parameterised constructor
        {
            this.number = number;
            this.floor = floor;
            this.type = type;
            this.capacity = capacity;
           
            this.bookedTime = bookedTime;
            this.price = price;

        }

        public override string ToString() //override toString method
        {
            return $"Number:{this.number}\n"+
                $"Floor:{this.floor}\n" +
                $"Type: { this.type}\n" +
                $"Capacity:{this.capacity}\n" +
                $"BookedTime:{this.bookedTime}\n" +

               $"Price: { this.price}";
        }

        static void Main()
        {
            Console.WriteLine("Enter room number:");
            int number = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter floor number:");
            int floor = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter type:");
            string type = Console.ReadLine();

            Console.WriteLine("Enter capacity:");
            int capacity = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Booked time:");
            DateTime bookedTime = Convert.ToDateTime(Console.ReadLine());

            Console.WriteLine("Enter price:");
            double price = Convert.ToDouble(Console.ReadLine());

            Room room = new Room(number,floor,type,capacity,bookedTime,price);
            Console.WriteLine($"user details are: s {room} ");
           Console.ReadLine();
        }
    }
}
