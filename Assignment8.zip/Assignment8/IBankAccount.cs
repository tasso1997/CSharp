﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    interface IBankAccount
    {
        void Deposit(double amount);
        void Withdraw(double amount);

    }
    class SavingAccount : IBankAccount
    {
        int accountNo;
        double balance;

        public void Deposit(double amount)
        {
            Console.WriteLine($"Depositing Rupees {amount} in saving accounts");
            balance = balance + amount;
            Console.WriteLine($"After Deposit ->new balance is {balance}");
        }

       public void Withdraw(double amount)
        {
            Console.WriteLine($"Withdrawing from saving accounts rupees {amount} ");
            balance = balance - amount;
            Console.WriteLine($"After Withdraw ->new balance is {balance}");
        }

    }

    class CurrentAccount : IBankAccount
    {
        int accountNo;
        double balance;

        public void Deposit(double amount)
        {
            Console.WriteLine($"Depositing Rupees {amount} in current accounts");
            balance = balance + amount;
            Console.WriteLine($"After Deposit ->new balance is {balance}");
        }

        public void Withdraw(double amount)
        {
            Console.WriteLine($"Withdrawing from current accounts rupees {amount} ");
            balance = balance - amount;
            Console.WriteLine($"After Withdraw ->new balance is {balance}");
        }

    }
    class BankDemo
    {
        static void Main()
        {
            SavingAccount save = new SavingAccount();
            CurrentAccount current = new CurrentAccount();

            save.Deposit(1200);
            save.Deposit(1000);
            save.Withdraw(1000);

            current.Deposit(2000);
            current.Withdraw(1000);
            current.Deposit(1000);
            Console.ReadLine();
        }
    }
}
