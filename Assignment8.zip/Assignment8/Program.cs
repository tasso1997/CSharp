﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    abstract class Computer
    {
        public abstract void BootUp();
        public abstract void ShutDown();
    }
    class SuperComputer:Computer //override abstract method Computer
    {
        public override void BootUp()
        {
            Console.WriteLine("Super computer is booting up");
        }
        public override void ShutDown()
        {
            Console.WriteLine("Super computer is shuting down");
        }
    }

    class MainFrameComputer : Computer //override abstract method Computer
    {
        public override void BootUp()
        {
            Console.WriteLine("Super computer is booting up");
        }
        public override void ShutDown()
        {
            Console.WriteLine("Super computer is shuting down");
        }
    }

    class MicroComputer : Computer //override abstract method Computer
    {
        public override void BootUp()
        {
            Console.WriteLine("Super computer is booting up");
        }
        public override void ShutDown()
        {
            Console.WriteLine("Super computer is shuting down");
        }
    }

    public sealed class Pen //sealed class to restrict override method
    {
        void StartWriting()
        {
            Console.WriteLine("Start writing");
        }
       void StopWriting()
        {
            Console.WriteLine("Stop Writing");
        }
    }


}
