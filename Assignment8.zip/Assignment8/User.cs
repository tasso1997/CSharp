﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    class User
    {
        private long id;
        private string name;
        private string emailId;
        private string dateOfBirth;

        public long Id//using properties

        {
            get
            {
                return id;
            }
            set
            {
                id = value;
            }
        }

        public string Name

        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public string EmailId

        {
            get
            {
                return emailId;
            }
            set
            {
                emailId = value;
            }
        }

        public string DateOFBirth

        {
            get
            {
                return dateOfBirth;
            }
            set
            {
                dateOfBirth = value;
            }
        }

        public User()//default constructor
        {
            Console.WriteLine("Default constructor of user");
        }

        public User(long id, string name, string emailId, string dateOfBirth)  //parameterised constructor
        {
            this.id = id;
            this.name = name;
            this.emailId = emailId;
            this.dateOfBirth = dateOfBirth;

        }
        public override string ToString() //override toString method
        {
            return $"Id:{this.id}\n" +
                $"Name:{this.name}\n" +
                $"EmailId { this.emailId}\n" +
                $"DateOFBirth:{this.dateOfBirth}";

        }

        static void Main()
        {
            Console.WriteLine("Enter ID:");
            long id = Convert.ToInt64(Console.ReadLine());

            Console.WriteLine("Enter name:");
            string name = Console.ReadLine();

            Console.WriteLine("Enter EMAIL ID:");
            string emailId = Console.ReadLine();

            Console.WriteLine("Enter DATE OF BIRTH:");
            string dateOfBirth = Console.ReadLine();



            User user = new User(id, name, emailId, dateOfBirth);
            Console.WriteLine($"user details are:  {user} ");
            Console.ReadLine();
        }
    }
}
